The template of actual thesis.

The [phdthesis document class](phdthesis.cls) has option `showframe` to switch if to show geometry frame for texts or not.
