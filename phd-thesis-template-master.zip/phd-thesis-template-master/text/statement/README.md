The template of doctoral thesis statement.

The [phdthesisstatement document class](phdthesisstatement.cls) has option `showframe` to switch if to show geometry frame for texts or not.
