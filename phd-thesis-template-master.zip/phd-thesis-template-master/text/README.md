This directory contains LaTeX source code and figures for the outputs

#### outputs
- [main](main) ... actual thesis
- [poster](poster) ... poster
- [statement](statement) ... doctoral thesis statement
- [cd](cd) ... CD cover
- [presentation](presentation) ... defense presentation

#### common files
- [common](common) ... common LaTeX files for all outputs
- [figs](figs) ... common figures
