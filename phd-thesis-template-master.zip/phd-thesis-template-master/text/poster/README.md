The template of poster.

See comments in [the LaTeX file](PhD_thesis_Surname_2018_poster.tex) for more information how to use the template.
