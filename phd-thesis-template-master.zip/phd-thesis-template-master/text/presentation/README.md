The template of defense presentation using `beamer` class.
