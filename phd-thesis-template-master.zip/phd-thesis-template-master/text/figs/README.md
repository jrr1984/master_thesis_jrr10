Directory containing common figures.

[ctu directory](ctu) contains CTU symbols.
