The template of CD cover.

The [phdcd document class](phdcd.cls) has option `showcircles` to switch if to show circles of CD dimensions.
