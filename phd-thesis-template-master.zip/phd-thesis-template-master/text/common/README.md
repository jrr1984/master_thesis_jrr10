Common files used by all document types

#### What is here
- [thesisdata.tex](thesisdata.tex) ... common data about the thesis (name, author, abstract, etc. etc.)
- [commands.tex](commands.tex) ... user defined commands. In this case, only commands to fill documents by a dummy text are defined
- [references.bib](references.bib) ... BibTeX file containing references cited
